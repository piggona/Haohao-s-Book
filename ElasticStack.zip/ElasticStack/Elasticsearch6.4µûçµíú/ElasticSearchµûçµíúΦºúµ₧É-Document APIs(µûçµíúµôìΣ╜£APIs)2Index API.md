# ElasticSearch文档解析-Document APIs(文档操作APIs)2:Index API

